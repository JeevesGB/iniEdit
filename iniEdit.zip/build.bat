@echo off
setlocal
title Build iniEdit
cd /d "%~dp0"

set "APP_NAME=iniEdit"
set "OUT_DIR=%~dp0builds"
set "WORK_DIR=%~dp0builds\_work"

echo ==================================================
echo  Building %APP_NAME%
echo ==================================================
echo.

rem --- Make sure everything the exe bundles is present ---
for %%F in ("src\main.py" "src\gui\app.py" "src\gui\start_dialog.py" "src\gui\guide.py" "src\gui\curve_panel.py" "src\gui\gear_panel.py" "src\gui\theme.py" "src\gui\tooltip.py" "src\gui\model_panel.py" "src\core\settings.py" "src\core\project.py" "src\core\curve.py" "src\core\gearing.py" "src\core\modeltools.py" "src\data\car_mod_schema.json" "src\data\cars.json" "src\tools\prepare.py" "src\gui\icons\ico.ico" "build_icon.py" "requirements.txt") do (
    if not exist "%%~F" (
        echo ERROR: Missing %%~F
        goto :fail
    )
)
for %%I in (model_tools gearbox curve) do (
    if not exist "src\gui\icons\%%I.png" echo NOTE: src\gui\icons\%%I.png not found - that tab will have no icon.
)

rem --- Find Python (the "python" command, or the "py" launcher as a fallback) ---
set "PY=python"
python --version >nul 2>&1
if not errorlevel 1 goto :have_python
set "PY=py -3"
py -3 --version >nul 2>&1
if not errorlevel 1 goto :have_python
echo ERROR: Python was not found on PATH ^(tried "python" and "py -3"^).
goto :fail
:have_python
%PY% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
    echo ERROR: This Python has no tkinter. Reinstall Python with "tcl/tk and IDLE" ticked.
    goto :fail
)

rem --- Syntax-check the source so a broken file fails here, not inside the exe ---
echo Checking source...
%PY% -m compileall -q "src" >nul
if errorlevel 1 (
    echo ERROR: A source file has a syntax error. Run: %PY% -m compileall src
    goto :fail
)

rem --- Make sure project requirements are installed ---
echo Checking requirements...
%PY% -m pip install -q -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install requirements.
    goto :fail
)

rem --- Import every module, so a NameError / bad import fails here instead of inside the exe ---
echo Checking imports...
%PY% -c "import sys; sys.path.insert(0, 'src'); import core.curve, core.gearing, core.schema, core.ini_model, core.project, core.modeltools, core.settings, core.discdata, gui.app, gui.curve_panel, gui.gear_panel, gui.theme, gui.tooltip, gui.model_panel, gui.paints_panel, gui.preview_panel, gui.start_dialog, gui.guide" 
if errorlevel 1 (
    echo ERROR: A module failed to import ^(see the message above^).
    goto :fail
)

rem --- Make sure PyInstaller is available ---
%PY% -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo PyInstaller not found, installing...
    %PY% -m pip install -q pyinstaller
    if errorlevel 1 (
        echo ERROR: Failed to install PyInstaller.
        goto :fail
    )
)

if not exist "%OUT_DIR%" mkdir "%OUT_DIR%"

rem --- Remove the previous exe so a failed build can't leave a stale one ---
if exist "%OUT_DIR%\%APP_NAME%.exe" del /q "%OUT_DIR%\%APP_NAME%.exe"

rem --- Rewrite the icon as a clean multi-size .ico (falls back to the original) ---
set "ICON_FILE=%TEMP%\ico.ico"
if exist "%ICON_FILE%" del /q "%ICON_FILE%"
%PY% build_icon.py "%~dp0src\gui\icons\ico.ico" "%ICON_FILE%"
if not exist "%ICON_FILE%" (
    echo NOTE: could not rewrite the icon, using the original file.
    set "ICON_FILE=%~dp0src\gui\icons\ico.ico"
)

echo.
echo Running PyInstaller...
echo.

%PY% -m PyInstaller ^
    --noconfirm ^
    --clean ^
    --onefile ^
    --windowed ^
    --name "%APP_NAME%" ^
    --icon "%ICON_FILE%" ^
    --paths "src" ^
    --distpath "%OUT_DIR%" ^
    --workpath "%WORK_DIR%" ^
    --specpath "%WORK_DIR%" ^
    --add-data "%~dp0src\data;data" ^
    --add-data "%~dp0src\gui\icons;gui\icons" ^
    --add-data "%~dp0src\tools;tools" ^
    --hidden-import gui.start_dialog ^
    --hidden-import gui.curve_panel ^
    --hidden-import gui.gear_panel ^
    --hidden-import gui.theme ^
    --hidden-import gui.tooltip ^
    --hidden-import core.gearing ^
    --exclude-module PyQt5 ^
    --exclude-module PyQt6 ^
    --exclude-module PySide2 ^
    --exclude-module PySide6 ^
    --exclude-module IPython ^
    --exclude-module wx ^
    --hidden-import PIL._tkinter_finder ^
    --hidden-import PIL.ImageTk ^
    --hidden-import matplotlib.backends.backend_tkagg ^
    "src\main.py"

if errorlevel 1 (
    echo.
    echo ERROR: PyInstaller build failed.
    goto :fail
)

rem --- Check the build really produced the exe ---
if not exist "%OUT_DIR%\%APP_NAME%.exe" (
    echo ERROR: PyInstaller finished but %APP_NAME%.exe was not created.
    goto :fail
)

rem --- Ship the icon credits next to the exe ---
if exist "src\Credits.txt" copy /y "src\Credits.txt" "%OUT_DIR%\Credits.txt" >nul
if exist "README.md" copy /y "README.md" "%OUT_DIR%\README.md" >nul
if exist "LICENSE" copy /y "LICENSE" "%OUT_DIR%\LICENSE.txt" >nul

rem --- Clean up temporary build files (only the exe + credits remain in builds) ---
if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%"

rem --- Ask Windows to refresh its icon cache so Explorer shows the new exe icon ---
ie4uinit.exe -show >nul 2>&1

echo.
echo ==================================================
echo  Build complete:
echo  %OUT_DIR%\%APP_NAME%.exe
for %%S in ("%OUT_DIR%\%APP_NAME%.exe") do echo  Size: %%~zS bytes
echo ==================================================
echo.
pause
exit /b 0

:fail
echo.
echo Build failed.
if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%"
pause
exit /b 1
